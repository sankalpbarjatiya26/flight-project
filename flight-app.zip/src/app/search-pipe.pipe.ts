import { Pipe, PipeTransform } from '@angular/core';
import { Flight } from './flight';

@Pipe({
  name: 'searchPipe'
})
export class SearchPipePipe implements PipeTransform {

  transform(flights: Flight[],filterString:string) {

    console.log('Filter pipe called');
    if(flights.length===0 || filterString===''){
     return  flights;
 
    }else{
     return flights.filter((fly) =>{
         return fly.flight_name.toLowerCase()===filterString.toLowerCase()
      })
       }
    }

}
