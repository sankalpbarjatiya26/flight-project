import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Flight } from '../../flight';
import { FlightserviceService } from '../../flightservice.service';

@Component({
  selector: 'app-bookflights',
  templateUrl: './bookflights.component.html',
  styleUrls: ['./bookflights.component.css']
})
export class BookflightsComponent {
  flightForm:Flight={
    id:0,
    flight_name:'',
    departure_from:'',
    departure_to:'',
    price:0
    
  }

constructor(private FlightService:FlightserviceService,
  private router:Router) { }

 ngOnInit():void{}


create(){
  this.FlightService.createflights(this.flightForm).subscribe({
      next: (data) =>{
        this.router.navigate(['/flightList'])
      },
      error:(err)=>{
        console.log(err);
      }
    })
}







}
