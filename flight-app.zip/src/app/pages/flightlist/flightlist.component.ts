import { Component } from '@angular/core';
import { FlightserviceService } from '../../flightservice.service';
import {Flight} from '../../flight'
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-flightlist',
  templateUrl: './flightlist.component.html',
  styleUrls: ['./flightlist.component.css']
})
export class FlightlistComponent {
  public flights:Flight[] | any;
  filterString='';
  FlightserviceService: any;
  constructor(private flightservice:FlightserviceService ,
    private route: ActivatedRoute,
    private router: Router
    ){} //yahi hai
    
  
 ngOnInit(){
  this.flightservice.getAllflights().subscribe((res:Flight[])=>{
    this.flights=res;
  

  });
 }
 allflights:Flight[] =[];
 delete(delid:number){
  console.log("delete in progress");
  this.flightservice.delete(delid).subscribe({
    next:(data)=>{
    this.allflights=this.allflights.filter(_=> _ .id!=delid)
    this.router.navigate(["/flightlist"]);
    this.ngOnInit()
    window.location.reload();
    },
    error:(err)=>{
         console.log(err);
    }
  })
 }




}
