import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Flight } from 'src/app/flight';
import { FlightserviceService } from 'src/app/flightservice.service';

@Component({
  selector: 'app-flight-edit',
  templateUrl: './flight-edit.component.html',
  styleUrls: ['./flight-edit.component.css']
})
export class FlightEditComponent {


  flightForm:Flight={
    id:0,
    flight_name:'',
    departure_from:'',
    departure_to:'',
    price:0
    
  }
  constructor(
    private FlightService:FlightserviceService,
    private route: ActivatedRoute,
    private router: Router,
    
  
  ){}


  ngOnInit(): void{
    this.route.paramMap.subscribe((param)=>{
      var id =Number(param.get('id'));
      this.getByID(id);
      
    });
  }
  getByID(id:number){
    this.FlightService.getByID(id).subscribe((data:any)=>{
      this.flightForm=data;
    });
  
  }


  update(){
    this.FlightService.update(this.flightForm).subscribe({
      next:(data)=>{
        this.router.navigate(["/flightList"]);
    },
      error:(err)=>{
        console.log(err);
      }
    });
  }



 

}
