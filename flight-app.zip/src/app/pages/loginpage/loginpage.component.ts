import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent {


  logInForm=new FormGroup({
    user : new FormControl(null,Validators.required),
    pass : new FormControl(null,Validators.required)  })
    logInUser(){
      console.log(this.logInForm.value);
    }
    get user(){
      return this.logInForm.get('user');
    }
    get pass(){
      return this.logInForm.get('pass');
}
  
}
