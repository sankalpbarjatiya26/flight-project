import { Component } from '@angular/core';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})

export class HomepageComponent {

  // constructor () { }

     CardData:CardInterface[] = [
      {
        title:'Vistara Airlnes',
        desc:'With supporting text below as a natural lead-in to additional content.'
      },
      {
        title:'Indigo',
        desc:'With supporting text below as a natural lead-in to additional content.'
      },
      {
        title:'Kingfisher',
        desc:'With supporting text below as a natural lead-in to additional content.'
      },
      {
        title:'SpiceJet',
        desc:'With supporting text below as a natural lead-in to additional content.'
      }, 
    ]
}


export interface CardInterface {
  title: string,
  desc?:string,
}