import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponentComponent } from '../app/component/navbar-component/navbar-component.component';

import { SliderComponentComponent } from '../app/component/slider-component/slider-component.component';
import { HomepageComponent } from './pages/homepage/homepage.component';
import { LoginpageComponent } from './pages/loginpage/loginpage.component';
import { CardComponentComponent } from './component/card-component/card-component.component';
import { FlightlistComponent } from './pages/flightlist/flightlist.component';
import { HttpClientModule } from '@angular/common/http';
import { FooterComponent } from './component/footer/footer.component';
import { BookflightsComponent } from './pages/bookflights/bookflights.component';
import { FlightEditComponent } from './pages/flight-edit/flight-edit.component';
// import { HomeComponentComponent } from './component/home-component/home-component.component';
// import { NavbarComponentComponent } from './component/navbar-component/navbar-component.component';
// import { SliderComponentComponent } from './component/slider-component/slider-component.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SearchPipePipe } from './search-pipe.pipe';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponentComponent,
    // HomeComponent,
    SliderComponentComponent,
    HomepageComponent,
    LoginpageComponent,
    // HomeComponentComponent,
    NavbarComponentComponent,
    SliderComponentComponent,
    CardComponentComponent,
    FlightlistComponent,
    FooterComponent,
    BookflightsComponent,
    FlightEditComponent,
    SearchPipePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
