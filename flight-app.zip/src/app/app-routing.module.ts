import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from '../app/pages/homepage/homepage.component';
import { LoginpageComponent } from './pages/loginpage/loginpage.component';
import { FlightlistComponent } from './pages/flightlist/flightlist.component';
import { BookflightsComponent } from './pages/bookflights/bookflights.component';
import { FlightEditComponent } from './pages/flight-edit/flight-edit.component';

const routes: Routes = [


  // { path:'/' , redirectTo: 'home'},
  {path: 'home', component:HomepageComponent,},
  {path:'login',component:LoginpageComponent},
  {path:'flightList',component:FlightlistComponent},
  {path:'bookflight',component:BookflightsComponent},
  {path:'Edit/:id',component:FlightEditComponent},
  {path:'**',component:HomepageComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
