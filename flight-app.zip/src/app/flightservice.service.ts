import { Injectable } from '@angular/core';
import{HttpClient, HttpClientModule} from '@angular/common/http';

import { Flight } from 'src/app/flight';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FlightserviceService {

  constructor(private http:HttpClient) { }
  public getAllflights(): Observable<Flight[]> { //used for async api calls
    return  this.http.get<Flight[]>(`http://localhost:8080/api/fly`);
  }


  createflights(data:any){
    return this.http.post<any>(`http://localhost:8080/api/flight` ,data)

    .pipe(map((res:any)=>{
      return res;
    }))
  }


  getByID(id:number){
    return this.http.get<Flight>(`http://localhost:8080/api/flight/${id}`);
  }

  delete(id:number){
    console.log("HeeDelete")
    return this.http.delete<Flight>(`http://localhost:8080/api/flight/${id}`);
  }

  update(payload:Flight){
    return this.http.put<Flight>(`http://localhost:8080/api/flight/${payload.id}`,payload);
  }


}
