export interface Flight{
    id:number;
    flight_name:string;
    departure_from:string;
    departure_to:string;
    price:number;
}