import { SearchPipePipe } from './search-pipe.pipe';

describe('SearchPipePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchPipePipe();
    expect(pipe).toBeTruthy();
  });
});
